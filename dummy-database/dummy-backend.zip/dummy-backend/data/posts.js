const fs = require('node:fs/promises');

async function getStoredPosts() {
  const rawFileContent = await fs.readFile('posts.json', { encoding: 'utf-8' });
  const data = JSON.parse(rawFileContent);
  const storedPosts = data.posts ?? [];
  return storedPosts;
}

function storePosts(posts) {
  return fs.writeFile('posts.json', JSON.stringify({ posts: posts || [] }));
}

async function removePost(postId) {
  const storedPosts = await getStoredPosts();
  const updatedPosts = storedPosts.filter((post) => post.id !== postId);
  await storePosts(updatedPosts);
}

async function updatePost(postId, updatedData) {
  const storedPosts = await getStoredPosts();
  const updatedPosts = storedPosts.map((post) =>
    post.id === postId ? { ...post, ...updatedData } : post
  );
  await storePosts(updatedPosts);
}

exports.getStoredPosts = getStoredPosts;
exports.storePosts = storePosts;
exports.removePost = removePost;
exports.updatePost = updatePost;
